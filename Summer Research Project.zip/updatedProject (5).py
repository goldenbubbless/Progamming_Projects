from bs4 import BeautifulSoup
import requests
import pandas as pd
import regex as re
import nltk
nltk.download('punkt')
from nltk.tokenize import sent_tokenize



indexfile = r'https://www.sec.gov/Archives/edgar/full-index/2020/QTR2/company.idx'
 
col_specification = [(0, 61), (62, 73), (74, 85), (86, 97), (98, 159)]
dataframe = pd.read_fwf(indexfile, colspecs=col_specification, skiprows=9)
urls=[]
#name the columns
filing_type = ['10-K','10-Q','8-K']
dataframe.columns = ['company_name','form_type','cik','date','file_name']
whole_dataframe = dataframe[dataframe['form_type'].isin(filing_type)]

#remove the hastag from whichever part of the dataframe you're working on before running the program

#firstPart= whole_dataframe.iloc[:6965]

#secondPart=whole_dataframe.iloc[6965:13930]

#thirdPart=whole_dataframe.iloc[13930:20895]

#fourthPart=whole_dataframe.iloc[20895:27861]

the_word1 = "pandemic"
the_word2 = "COVID-19"
the_word3='covid 19'
the_word4='coronavirus'
the_word5='SARS-CoV-2'
the_word6='outbreak'
the_word7="Covid-19"
the_word9='Coronavirus'
the_word10='covid-19'
the_word11='COVID 19'
the_word12='Covid 19'
the_word13='epidemic'
the_word14='infectious diease'
the_word15='contagious disease'


f=open("PandemicDataErrors.txt", 'w')
count=0


rx = re.compile(r'^$', flags = re.MULTILINE | re.VERSION1)
#replace whole_dataframe with either firstPart, secondPart, thirdPart or fourthPart(whichever you're doing)
for i,row in whole_dataframe.iterrows():

    url = "https://www.sec.gov/Archives/"+ row["file_name"]
    result=requests.get(url)
    src=result.content
    soup=BeautifulSoup(src,'lxml')


    section = [part for part in rx.split(soup.text)
                            if (the_word1 in part or 
                                the_word2 in part or 
                                the_word3 in part or 
                                the_word4 in part or 
                                the_word5 in part or 
                                the_word6 in part or
                                the_word7 in part or 
                                the_word9 in part or 
                                the_word10 in part or
                                the_word11 in part or 
                                the_word12 in part or 
                                the_word13 in part or 
                                the_word14 in part or 
                                the_word15 in part ) ]
    if section==[] and row['form_type']=='10-K':

        dict = {'company_name': [row['company_name']], 'form_type': [row['form_type']], 'date': [row['date']], 'cik':[row['cik']], 'data':['']}  

        df = pd.DataFrame(dict) 
 
        df.to_csv('q2combinedData.csv', mode='a+', header=False)

    elif section!= [] :

        count+=1
        print(count)

        f.flush()
        for paragraph in section :
            sentencesWithHighlights=[]
            try :
                    if the_word1 in paragraph:
                        index = paragraph.index(the_word1)              
                    elif the_word2 in paragraph:
                        index = paragraph.index(the_word2)

                    elif the_word3 in paragraph:
                        index = paragraph.index(the_word3)
                        
                    elif the_word4 in paragraph:
                        index = paragraph.index(the_word4)
                       
            
                    elif the_word5 in paragraph:
                        index = paragraph.index(the_word5)
                        
                    elif the_word6 in paragraph:
                        index = paragraph.index(the_word6)
                    elif the_word7 in paragraph:
                        index = paragraph.index(the_word7)
                    elif the_word9 in paragraph:
                        index = paragraph.index(the_word9)
                    elif the_word10 in paragraph:
                        index = paragraph.index(the_word10)
                    elif the_word11 in paragraph:
                        index = paragraph.index(the_word11)
                    elif the_word12 in paragraph:
                        index = paragraph.index(the_word12)
                    elif the_word13 in paragraph:
                        index = paragraph.index(the_word13)
                    elif the_word14 in paragraph:
                        index = paragraph.index(the_word14)
                    elif the_word15 in paragraph:
                        index = paragraph.index(the_word15)

                    subtractFromIndex = 0
                    for sentence in sent_tokenize(paragraph):
                        if 0 < index - subtractFromIndex < len(sentence):
                            sentencesWithHighlights.append(sentence)
                            break
                        subtractFromIndex += len(sentence)
                    dict = {'company_name': row['company_name'], 'form_type': row['form_type'], 'date': row['date'], 'cik':row['cik'], 'data':sentencesWithHighlights}  
    
                    df = pd.DataFrame(dict) 
                    
                    df.to_csv('q2combinedData.csv', mode='a+', header=False)
            except :
                print(('Error:',row['company_name'],row['form_type'],row['date'],row['cik']),file=f)
if not f._checkClosed():
    f.close()