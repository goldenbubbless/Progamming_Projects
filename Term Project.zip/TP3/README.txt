README FILE

DESCRIPTION:
The project is a basic financial analysis that consists of three parts: 
- a sentiment analysis performed on a single stock that will suggest the user to buy or sell a stock
- a portfolio analysis that will return to the user the optimal amount of each stock the user should buy according to the risk 
- stock prediction for a certain amount of days that the user selects

The first thing I did was a user login and password using File I/O. The user will input a username and password and for
security reasons, I will encrypt it using a caesar cipher. It will store the username and password into a file for future purposes.

For the sentiment analysis, I used nltk and a SentimentIntensityAnalyzer that looked at the headlines that 
I manually webscraped. From there, I decided on what range of numbers would make the headline positive, negative, or neutral.
If the headlines had a majority of positive, I assigned the stock as a BUY. I did the same for negative headlines.
 
For the portfolio analysis, I performed a Monte Carlo simulation that ran 1000 trials of different weights 
for each stock that the user inputs and calculated the consequent return and risk of each portfolio. 
From there I picked the list of weights that had the highest Sharpe Ratio to be the optimal portfolio weights. 

Similarly, I used a Monte Carlo simulation that will ran 100 trials on a year's worth of stock data
for the stock that the user inputs and calculated the consequent predicted volatility and increase/decrease in stock price. 
The repeated simulation will simulate the stock price for up to 30 days.

HOW TO RUN THE PROJECT:
You can run the main file and cmu_112_graphics.py in VS Code. You must run the main file along with cmu_112_graphics.py file in the same 
folder since it relies on that file for the user interface.

LIBRARIES:
from cmu_112_graphics import *
from bs4 import BeautifulSoup
import requests
import nltk
nltk.download('vader_lexicon')
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import pandas as pd
from pandas_datareader import DataReader
import numpy as np
import webbrowser

SHORTCUTS:
N/A
