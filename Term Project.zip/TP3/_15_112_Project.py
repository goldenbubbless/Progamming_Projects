#imported the file from: https://www.cs.cmu.edu/~112/notes/notes-animations-part1.html
from cmu_112_graphics import *
from bs4 import BeautifulSoup
import requests
import nltk
nltk.download('vader_lexicon')
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import pandas as pd
from pandas_datareader import DataReader
import numpy as np
import webbrowser


#use app modes to organize code
def appStarted(app):
    app._root.resizable(False, False) #taken from piazza post about window resizing (Sara's reply)
    app.users={}
    app.f= open("userPass.txt","a+")
    #https://www.geeksforgeeks.org/python-seek-function/
    app.f.seek(0, 0)
    fl =app.f.readlines()
    for line in fl:
        line = line.strip()
        if line !='':
            parts=line.split('=')
            user=parts[0]
            password=parts[1]
            if user not in app.users:
                app.users[user]=password

    app.cx=app.width//2
    app.cy=app.height//2
    app.mode='start'
    app.actionName='splash'
    app.inputStockSentiment=''
    app.ret=None
    app.vol=None
    app.inputStockPortfolio=''
    app.inputStockPortfolio1=''
    app.inputStockPortfolio2=''
    app.inputStockPortfolio3=''
    app.inputStockPortfolio4=''
    app.inputStockPortfolio5=''
    app.inputStockPortfolio6=''
    app.inputStockPortfolio7=''
    app.inputStockPortfolio8=''
    app.inputStockPortfolio9=''
    app.portfolios=[]
    app.inputStockPrediction=''
    app.startTyping=False
    app.sentiment=''
    app.headlines=[]
    app.boxColor1='white'
    app.boxColor2='white'
    app.boxColor3='white'
    app.boxColor4='white'
    app.boxColor5='white'
    app.selectedRisk=''
    app.percents=None
    app.cx = app.width/2
    app.cy = app.height/2
    app.choosePredictionLength=False
    app.lastPrice=None
    app.average=None
    app.redrawStockPrediction=False
    app.redrawInputScreen=False
    app.redrawPickScreen=False
    app.user=False
    app.days=None
    app.boxColor6='white'
    app.boxColor7='white'
    app.boxColor8='white'
    app.boxColor9='white'
    app.actionList=[]
    app.portDict=None
    app.weight=None
    app.urls=[]
    app.error=False
    app.inputUser=''
    app.inputPass=''
    app.wrongPassword=False

def appStopped(app):
    app.f.close()

def keyPressed(app,event):
    app.error=False
    try:
        if app.mode=='user':
            if event.key.isalpha()==True and len(event.key)==1:
                app.inputUser+=event.key
                app.startTyping=True
            elif event.key=="Backspace":
                app.inputUser=app.inputUser[:-1]
        elif app.mode=='pass':
            if event.key.isalnum()==True and len(event.key)==1:
                app.inputPass+=event.key
                app.startTyping=True
            elif event.key=="Backspace":
                app.inputPass=app.inputPass[:-1]

        if event.key=="Space" and (app.mode=='pass'):
            
            if checkUser(app,app.inputUser,app.inputPass)==True:
                app.actionName='introScreen'
                app.user=True
                app.mode='userPicks'
                app.actionList.append((app.actionName,app.mode))
            else:
              
                app.mode='error'
                app.actionName='drawError'
                app.error=True
                app.actionList.append((app.actionName,app.mode))
                app.inputUser=''
                app.inputPass=''

        if app.mode=='sentStock':
            if event.key=="Enter":
                app.startTyping=False
                app.mode='sentimentAnalysis'
                senti=determineSentiment(app,app.inputStockSentiment)
                app.sentiment=senti[0]
                app.headlines=senti[1].head(10)
                app.urls=senti[2].head(10)
                app.actionList.append(('',app.mode))
            elif event.key=="Backspace":
                app.inputStockSentiment=app.inputStockSentiment[:-1]
            else:
                if event.key.isalpha()==True and len(event.key)==1:
                    app.inputStockSentiment+=event.key
                    app.startTyping=True

        if app.mode=='portStock'or app.mode=='portStock1' or app.mode=='portStock2'or \
            app.mode=='portStock3'or app.mode=='portStock4'or app.mode=='portStock5'or \
                app.mode=='portStock6' or app.mode=='portStock7'or app.mode=='portStock8' or \
                    app.mode=='portStock9':
            if event.key=="Enter":
                app.startTyping=False
                app.mode='portfolioAnalysis'
                app.actionName='drawPortfolio'
                app.portfolios.extend((app.inputStockPortfolio,app.inputStockPortfolio1, \
                    app.inputStockPortfolio2, app.inputStockPortfolio3,app.inputStockPortfolio4 \
                        ,app.inputStockPortfolio5,app.inputStockPortfolio6,app.inputStockPortfolio7 \
                            ,app.inputStockPortfolio8,app.inputStockPortfolio9))
                lst=performPortfolioAnalysis(app,app.portfolios)
                app.portDict=allPortfolios(app,lst)
                app.percents=selectedPortfolio(app)
                lst=[app.inputStockPortfolio,app.inputStockPortfolio1,app.inputStockPortfolio2,\
                     app.inputStockPortfolio3,app.inputStockPortfolio4,app.inputStockPortfolio5,\
                     app.inputStockPortfolio6,app.inputStockPortfolio7,app.inputStockPortfolio8,app.inputStockPortfolio9]
                for port in lst:
                    port=''
                app.portfolios=[]
                app.actionList.append((app.actionName,app.mode))

            else:
                if app.mode=='portStock':
                    if event.key=="Backspace":
                        app.inputStockPortfolio=app.inputStockPortfolio[:-1]
                    else:
                        if event.key.isalpha()==True and len(event.key)==1:
                            app.inputStockPortfolio+=event.key
                            app.startTyping=True
                           
                if app.mode=='portStock1':
                    if event.key=="Backspace":
                        app.inputStockPortfolio1=app.inputStockPortfolio1[:-1]
                    else:
                        if event.key.isalpha()==True and len(event.key)==1:
                            app.inputStockPortfolio1+=event.key
                            app.startTyping=True
                       
                if app.mode=='portStock2':
                    if event.key=="Backspace":
                        app.inputStockPortfolio2=app.inputStockPortfolio2[:-1]
                    else:
                        if event.key.isalpha()==True and len(event.key)==1:
                            app.inputStockPortfolio2+=event.key
                            app.startTyping=True
           
                if app.mode=='portStock3':
                    if event.key=="Backspace":
                        app.inputStockPortfolio3=app.inputStockPortfolio3[:-1]
                    else:
                        if event.key.isalpha()==True and len(event.key)==1:
                            app.inputStockPortfolio3+=event.key
                            app.startTyping=True

                if app.mode=='portStock4':
                    if event.key=="Backspace":
                        app.inputStockPortfolio4=app.inputStockPortfolio4[:-1]
                    else:
                        if event.key.isalpha()==True and len(event.key)==1:
                            app.inputStockPortfolio4+=event.key
                            app.startTyping=True

                if app.mode=='portStock5':
                    if event.key=="Backspace":
                        app.inputStockPortfolio5=app.inputStockPortfolio5[:-1]
                    else:
                        if event.key.isalpha()==True and len(event.key)==1:
                            app.inputStockPortfolio5+=event.key
                            app.startTyping=True

                if app.mode=='portStock6':
                    if event.key=="Backspace":
                        app.inputStockPortfolio6=app.inputStockPortfolio6[:-1]
                    else:
                        if event.key.isalpha()==True and len(event.key)==1:
                            app.inputStockPortfolio6+=event.key
                            app.startTyping=True

                if app.mode=='portStock7':
                    if event.key=="Backspace":
                        app.inputStockPortfolio7=app.inputStockPortfolio7[:-1]
                    else:
                        if event.key.isalpha()==True and len(event.key)==1:
                            app.inputStockPortfolio7+=event.key
                            app.startTyping=True

                if app.mode=='portStock8':
                    if event.key=="Backspace":
                        app.inputStockPortfolio8=app.inputStockPortfolio8[:-1]
                    else:
                        if event.key.isalpha()==True and len(event.key)==1:
                            app.inputStockPortfolio8+=event.key
                            app.startTyping=True

                if app.mode=='portStock9':
                    if event.key=="Backspace":
                        app.inputStockPortfolio9=app.inputStockPortfolio9[:-1]
                    else:
                        if event.key.isalpha()==True and len(event.key)==1:
                            app.inputStockPortfolio9+=event.key
                            app.startTyping=True


        if app.mode=='stockPred':
            if event.key=="Enter":  
                app.mode='performPred'          
                app.startTyping=False
                app.actionName='predictStock'
                ret=stockPrediction(app,app.inputStockPrediction)
                app.lastPrice=ret[0]
                app.average=ret[1]
                app.actionList.append((app.actionName,app.mode))
            elif event.key=='Space':
                app.inputStockPrediction+=" "
                app.startTyping=True
            elif event.key=="Backspace":
                app.inputStockPrediction=app.inputStockPrediction[:-1]
            else:
                if event.key.isalpha()==True and len(event.key)==1:
                    app.inputStockPrediction+=event.key
                    app.startTyping=True
    except:
        lst=[app.inputStockPortfolio,app.inputStockPortfolio1,app.inputStockPortfolio2,\
             app.inputStockPortfolio3,app.inputStockPortfolio4,app.inputStockPortfolio5,\
             app.inputStockPortfolio6,app.inputStockPortfolio7,app.inputStockPortfolio8,app.inputStockPortfolio9]
        for port in lst:
            port=''
        app.portfolios=[]
        app.mode='error'
        app.actionName='drawError'
        app.error=True
        app.actionList.append((app.actionName,app.mode))


def mousePressed(app,event):
    if event.x<app.width/2+200 and event.x>app.width/2 and app.actionName=='splash':
        if event.y>app.height-300 and event.y<app.height-250:
            app.mode='user'
        elif event.y>app.height-200 and event.y<app.height-150:
            app.mode='pass'
            app.actionList.append((app.actionName,app.mode))
    if event.x>app.width/2.5 and event.x<app.width/1.5 and app.mode=='userPicks':
        if event.y>app.height/3.5 and event.y<app.height/2.5:
            app.actionName='sentimentAnalysis'
            app.mode='sentStock'
            app.actionList.append((app.actionName,app.mode))
        elif event.y>app.height/3.5+170 and event.y<app.height/2.5+170:
            app.actionName='portfolioAnalysis'
            app.mode='port'
            app.actionList.append((app.actionName,app.mode))
        elif event.y>app.height/1.4 and event.y<app.height/1.23:
            app.actionName='stockPrediction'
            app.mode='stockPred'
            app.actionList.append((app.actionName,app.mode))
    elif event.x>app.width/1.9 and event.x<app.width/1.5 and app.actionName=='portfolioAnalysis':    
        if event.y<app.height/1.9-150 and event.y>app.height/2.2-150:
            app.mode='portStock'
        if event.y<app.height/1.9-50 and event.y>app.height/2.2-50:
            app.mode='portStock1'
        if event.y<app.height/1.9+50 and event.y>app.height/2.2+50:
            app.mode='portStock2'
        if event.y<app.height/1.9+150 and event.y>app.height/2.2+150:
            app.mode='portStock3'
        if event.y<app.height/1.9+250 and event.y>app.height/2.2+250:
            app.mode='portStock4'
    if event.x>app.width/1.9+250 and event.x<app.width/1.5+260 and app.actionName=='portfolioAnalysis':
        if event.y<app.height/1.9-150 and event.y>app.height/2.2-150:
            app.mode='portStock5'
        if event.y<app.height/1.9-50 and event.y>app.height/2.2-50:
            app.mode='portStock6'
        if event.y<app.height/1.9+50 and event.y>app.height/2.2+50:
            app.mode='portStock7'
        if event.y<app.height/1.9+150 and event.y>app.height/2.2+150:
            app.mode='portStock8'
        if event.y<app.height/1.9+250 and event.y>app.height/2.2+250:
            app.mode='portStock9'

    if event.x>app.width-220 and event.x<app.width-50 and app.mode=='portfolioAnalysis' and app.actionName=='drawPortfolio':
        if event.y>app.height-100 and event.y<app.height-50:
            app.mode='seeAll'
            app.actionName='allPortfolios'
            app.actionList.append((app.actionName,app.mode))
    if event.x>app.width/3.55 and event.x<app.width/3.3 and app.actionName=='portfolioAnalysis':
        if event.y>app.height/3.1 and event.y<app.height/2.85:
            app.boxColor1='black'
            app.boxColor2='white'
            app.boxColor3='white'
            app.boxColor4='white'
            app.boxColor5='white'
            app.selectedRisk='Conservative'
        elif event.y>app.height/2.35 and event.y<app.height/2.2 and app.actionName=='portfolioAnalysis':
            app.boxColor2='black'
            app.boxColor1='white'
            app.boxColor3='white'
            app.boxColor4='white'
            app.boxColor5='white'
            app.selectedRisk='Moderately Conservative'
        elif event.y>app.height/1.87 and event.y<app.height/1.77 and app.actionName=='portfolioAnalysis' and app.mode=='port':
            app.boxColor3='black'
            app.boxColor2='white'
            app.boxColor1='white'
            app.boxColor4='white'
            app.boxColor5='white'
            app.selectedRisk='Moderately Aggressive'
        elif event.y>app.height/1.57 and event.y<app.height/1.5 and app.actionName=='portfolioAnalysis' and app.mode=='port':
            app.boxColor4='black'
            app.boxColor2='white'
            app.boxColor3='white'
            app.boxColor1='white'
            app.boxColor5='white'
            app.selectedRisk='Aggressive'
        elif event.y>app.height/1.35 and event.y<app.height/1.3 and app.actionName=='portfolioAnalysis' and app.mode=='port':
            app.boxColor5='black'
            app.boxColor2='white'
            app.boxColor3='white'
            app.boxColor4='white'
            app.boxColor1='white'
            app.selectedRisk='Very Aggressive'
    if event.x>10 and event.x<140:
        if event.y>10 and event.y<50:
           if len(app.actionList)>0:
               backValue=app.actionList.pop()
               backValue=app.actionList[-1]
               app.actionName=backValue[0]
               app.mode=backValue[1]
   
    elif event.y>app.height/1.5 and event.y<app.height/1.4:
        app.choosePredictionLength=True
        if event.x>app.width/5 and event.x<app.width/4.5+20 and app.choosePredictionLength==True:
            app.days=5
            app.boxColor6='black'
            app.boxColor7='white'
            app.boxColor8='white'
            app.boxColor9='white'
        elif event.x>200+app.width/5 and event.x<200+app.width/4.5+20 and app.choosePredictionLength==True:
            app.days=10
            app.boxColor7='black'
            app.boxColor6='white'
            app.boxColor8='white'
            app.boxColor9='white'
        elif event.x>400+app.width/5 and event.x<400+app.width/4.5+20 and app.choosePredictionLength==True:
            app.days=15
            app.boxColor8='black'
            app.boxColor7='white'
            app.boxColor6='white'
            app.boxColor9='white'
        elif event.x>600+app.width/5 and event.x<600+app.width/4.5+20 and app.choosePredictionLength==True:
            app.days=30
            app.boxColor9='black'
            app.boxColor7='white'
            app.boxColor8='white'
            app.boxColor6='white'
    if event.x<3*app.width/4+70 and event.x>3*app.width/4 and app.mode=='sentimentAnalysis':
        if event.y>app.height/2-5 and event.y<app.height/2+15:
            webbrowser.open(app.urls.iloc[0])
        if event.y>app.height/2+20 and event.y<app.height/2+40:
            webbrowser.open(app.urls.iloc[1])
        if event.y>app.height/2+45 and event.y<app.height/2+65:
            webbrowser.open(app.urls.iloc[2])
        if event.y>app.height/2+70 and event.y<app.height/2+90:
            webbrowser.open(app.urls.iloc[3])
        if event.y>app.height/2+95 and event.y<app.height/2+115:
            webbrowser.open(app.urls.iloc[4])
        if event.y>app.height/2+120 and event.y<app.height/2+140:
            webbrowser.open(app.urls.iloc[5])
        if event.y>app.height/2+145 and event.y<app.height/2+165:
            webbrowser.open(app.urls.iloc[6])
        if event.y>app.height/2+170 and event.y<app.height/2+190:
            webbrowser.open(app.urls.iloc[7])
        if event.y>app.height/2+195 and event.y<app.height/2+215:
            webbrowser.open(app.urls.iloc[8])
        if event.y>app.height/2+220 and event.y<app.height/2+240:
            webbrowser.open(app.urls.iloc[9])


def caesarEncrypt(string,shift):
    newstring = ""
    string=string.lower()
    for ch in string:
        if ch.isalpha():
            val=ord(ch)+shift
            if val>ord('z'):
                val-=(ord('z')-ord('a')+1)
            newstring=newstring+chr(val)
        else:
            newstring= newstring+ch
    return newstring

def checkUser(app,inputUser,inputPassword):
    encryptedPass=caesarEncrypt(inputPassword,8)
    if len(app.users)==0 or inputUser not in app.users:
        app.users[inputUser]=encryptedPass
        app.f.write(inputUser+'='+encryptedPass+'\n')
        app.f.flush()
    if app.users[inputUser]==encryptedPass:
        return True
    return False




#Yahoo Finance
def yahooScrape(ticker):
    urls=[]
    url=[]
    headlines=[]
    result=requests.get('https://finance.yahoo.com/quote/'+ ticker +'/news?p='+ticker)
    src=result.content
    soup=BeautifulSoup(src,'lxml')
    for h3_tag in soup.find_all('h3'): #returns a list
        headline=h3_tag.get_text()
        headlines.append(headline)
    lst=soup.find_all('a', class_="Fw(b) Fz(18px) Lh(23px) LineClamp(2,46px) Fz(17px)--sm1024 Lh(19px)--sm1024 LineClamp(2,38px)--sm1024 mega-item-header-link Td(n) C(#0078ff):h C(#000) LineClamp(2,46px) LineClamp(2,38px)--sm1024 not-isInStreamVideoEnabled")
    for tag in lst:
        url.append(tag.get('href'))
    for link in url:
        urls.append('https://finance.yahoo.com'+link)    
    return (headlines, urls)

#Seeking Alpha
def seekingAlphaScrape(ticker):
    urls=[]
    url=[]
    headlines=[]
    combinedList=[]
    result=requests.get('https://seekingalpha.com/symbol/'+ticker)
    src=result.content
    soup=BeautifulSoup(src,'lxml')
    for symbolClass in soup.find_all(class_='symbol_article'):
        a_tag=symbolClass.find('a')
        if a_tag:
            url.append(a_tag['href'])
            headlines.append(a_tag.contents)
    for link in url:
        urls.append('https://seekingalpha.com/'+link)
    for sub in headlines:
        for subitem in sub:
            combinedList.append(subitem)
    return (combinedList,urls)

def reutersScrape(ticker):
    urls=[]
    url=[]
    headlines=[]
    combinedList=[]
    result=requests.get('https://www.reuters.com/search/news?blob='+str(ticker.lower()))
    src=result.content
    soup=BeautifulSoup(src,'lxml')
    for searchClass in soup.find_all(class_='search-result-title'):
        a_tag=searchClass.find('a')
        if a_tag:
            url.append(a_tag['href'])
            headlines.append(a_tag.contents)
    for link in url:
        urls.append('https://www.reuters.com'+link)
    for sub in headlines:
        for subitem in sub:
            combinedList.append(subitem)
    return (combinedList,urls)


def createDataframe(totalList):
    return pd.DataFrame(totalList, columns = ['Headlines'], index=[i for i in range(len(totalList))])

#sentiment analyzer code loosely adapted from: https://maximumgenerality.wordpress.com/2016/10/03/sentiment-analysis-using-nlp/
def sentimentAnalysis(ticker):
    sentimentList=[]
    scoreList=[]
    urlsList=[]
    sia=SentimentIntensityAnalyzer()
    h1=yahooScrape(ticker)
    h2=seekingAlphaScrape(ticker)
    h3=reutersScrape(ticker)
    combinedList=h1[0]+ h2[0] + h3[0]
    combinedUrls=h1[1]+h2[1]+h3[1]
    for i in range(len(combinedList)):
        for j in range(len(combinedUrls)):
            if i==j:
                headline=combinedList[i]
                url=combinedUrls[j]
                scores = sia.polarity_scores(headline)
                if scores["compound"] > 0.1:
                    sentimentList.append("Positive")
                    scoreList.append(scores["compound"])
                    urlsList.append(url)
                elif scores["compound"] < 0.1:
                    sentimentList.append("Negative")
                    scoreList.append(scores["compound"])
                    urlsList.append(url)
                else:
                    sentimentList.append("Neutral")
                    scoreList.append(scores["compound"])
                    urlsList.append(url)
    df=createDataframe(combinedList)
    df["Sentiment"]=sentimentList
    df['Sentiment Scores']=scoreList
    df["Urls"]=urlsList
    return df

def determineSentiment(app,ticker):
    app.error=False
    try:
        df=sentimentAnalysis(ticker)
        sentimentDict={}
        for sentiment in df["Sentiment"]:
            if sentiment not in sentimentDict.keys():
                sentimentDict[sentiment]=0
            else:
                sentimentDict[sentiment]+=1
        if sentimentDict["Negative"]>sentimentDict["Positive"]:
            sent='BUY'
            df= df.sort_values('Sentiment Scores',ascending=False)
            topHeadlines = df['Headlines']
            topUrls=df["Urls"]
        elif sentimentDict["Negative"]<sentimentDict["Positive"]:
            sent='SELL'
            df= df.sort_values('Sentiment Scores',ascending=True)
            topHeadlines = df['Headlines']
            topUrls=df["Urls"]
        #reset index code from:https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.reset_index.html
        return (sent, topHeadlines.reset_index(drop=True),topUrls)
    except:
        app.mode='error'
        app.actionName='drawError'
        app.error=True
        app.actionList.append((app.actionName,app.mode))

def performPortfolioAnalysis(app,stocks):
    stockList=[]
    for stock in stocks:
        if stock!='':
            stock=stock.strip()
            stockList.append(stock)
    stockData=pd.DataFrame()
    for stock in stockList:
        stockData[stock]=DataReader(stock,'yahoo','2010-1-1')['Adj Close']  #daily prices of the stocks

    #to calculate the returns of a stock, you have to find the log(ending price-starting price)
    #shift by 1 is subtracting the second row value-first row value for every row pair

    stockReturns=np.log(stockData/stockData.shift(1))
    #new dataframe with the stocks log daily returns


#let user pick if they want low,medium,high risk portfolio
#according to that, the percent of the portfolio allocated to each stock will be calculated according to the risk


#portfolio allocation: https://www.investopedia.com/managing-wealth/achieve-optimal-asset-allocation/

#code is adapted from:https://s3.amazonaws.com/assets.datacamp.com/production/course_18408/slides/chapter1.pdf

    for stock in stockList:
        avgStockReturns=stockReturns.mean() #mean daily returns
        covStockReturns=stockReturns.cov() #covariance daily returns
    numStocks=len(stockList)
    portfolioReturns=[]
    portfolioVolatilities=[]
    weights=[]
    sharpeRatios=[]

#calculation of portfolio returns and portfolio volatilities adapted from:
#https://www.pythonforfinance.net/2017/01/21/investment-portfolio-optimisation-with-python/
    for i in range(1000):
        weightOfStock=np.random.random(numStocks)
        weightOfStock/=np.sum(weightOfStock)
        weights.append(weightOfStock)
        portfolioReturns.append(np.sum((weightOfStock*avgStockReturns))*250)
        portfolioVolatilities.append(np.sqrt(np.dot(weightOfStock.T,np.dot(covStockReturns*250,weightOfStock))))

    for i in range(len(portfolioReturns)):
        for j in range(len(portfolioVolatilities)):
            if i==j:
                sharpeRatio= portfolioReturns[i]/portfolioVolatilities[j]
                sharpeRatios.append(sharpeRatio)
    maxSharpeRatio=max(sharpeRatios)  
    portfolioDict={'Returns':portfolioReturns,'Volatilities':portfolioVolatilities, 'Sharpe Ratios':sharpeRatios, 'Weight':weights}
    idx=0
    for val in portfolioDict['Sharpe Ratios']:
        if val!=maxSharpeRatio:
            idx+=1
        else:
            app.ret=round((portfolioDict['Returns'][idx]),1)
            app.vol=round((portfolioDict['Volatilities'][idx]),1)
            w=list((portfolioDict['Weight'][idx]))
    colors=['red','orange','dark slate gray','green','blue','pink','purple','cyan','light blue','coral',
            'magenta','lavender','brown','hot pink','navy']
    zippedList=list(zip(stockList,w, colors))
    return zippedList

def percentOfPie(app,selectedRisk,lst):
    riskDict={}
    for pair in lst:
        stockName=pair[0]
        per=pair[1]
        if selectedRisk== 'Conservative':
            app.weight=0.15
            riskDict[stockName]=(app.weight*per,pair[2])
            riskDict["Cash and Equivalents"]=(0.1,'lime green')
            riskDict["Fixed Income Securities"]=(0.75,'turquoise')
        elif selectedRisk== 'Moderately Conservative':
            app.weight=0.35
            riskDict[stockName]=(app.weight*per,pair[2])
            riskDict["Cash and Equivalents"]=(0.05,'lime green')
            riskDict["Fixed Income Securities"]=(0.6,'turquoise')
        elif selectedRisk== 'Moderately Aggressive':
            app.weight=0.55
            riskDict[stockName]=(app.weight*per,pair[2])
            riskDict["Cash and Equivalents"]=(0.1,'lime green')
            riskDict["Fixed Income Securities"]=(0.35,'turquoise')
        elif selectedRisk== 'Aggressive':
            app.weight=0.55
            riskDict[stockName]=(app.weight*per,pair[2])
            riskDict["Cash and Equivalents"]=(0.20,'lime green')
            riskDict["Fixed Income Securities"]=(0.25,'turquoise')
        elif selectedRisk== 'Very Aggressive':
            app.weight=0.9
            riskDict[stockName]=(app.weight*per,pair[2])
            riskDict["Cash and Equivalents"]=(0.05,'lime green')
            riskDict["Fixed Income Securities"]=(0.05,'turquoise')
    return riskDict

def allPortfolios(app,lst):
    portfoliosDict={}
    risks=['Conservative','Moderately Conservative','Moderately Aggressive','Aggressive','Very Aggressive']
    for risk in risks:
        portfoliosDict[risk]=percentOfPie(app,risk,lst)
    return portfoliosDict

def selectedPortfolio(app):
    for k,v in app.portDict.items():
        if k==app.selectedRisk:
            return v
               

def stockPrediction(app,ticker):  
    stockPrices=DataReader(ticker,'yahoo','2010-1-1')['Adj Close']
    stockReturns=np.log(stockPrices/stockPrices.shift(1))
    lastPrice=stockPrices[-1]

    stockSim= pd.DataFrame()
    stockVolatility= stockReturns.std()
    #price volatility code adapted from: https://programmingforfinance.com/2017/11/monte-carlo-simulations-of-future-stock-prices-in-python/
    for i in range(100):
        prices = []    
        price = lastPrice * (1 + np.random.normal(0, stockVolatility))
        prices.append(price)
        for k in range(app.days):
            price = prices[k] * (1 + np.random.normal(0, stockVolatility))
            prices.append(price)
       
        stockSim[i] = prices
    averageRow = stockSim.mean(axis=1)
    return (lastPrice, averageRow.to_list())



#DRAWING THE CANVAS
def drawPerformStockPrediction(app,canvas):
    canvas.create_rectangle(0,0,app.width,app.height,fill='white')
    canvas.create_text(app.width,app.height,text=app.lastPrice+','+app.average,fill='black')

def drawSentimentAnalysis(app,canvas):
    canvas.create_rectangle(0,0,app.width,app.height,fill='#e8e7d2')
    canvas.create_text(app.width/2, app.height/2,text='Enter your stock (in ticker symbol!):',
                        font='Times 20 bold', fill='black')
    canvas.create_text(app.width/2, app.height/1.8,text='Press Enter To Continue',
                        font='Times 10 bold', fill='black')
    canvas.create_rectangle(app.width/3.5, app.height/1.5, app.width/1.5, app.height/1.75,fill='white')
    canvas.create_rectangle(10,10,140,50,fill='pink')
    canvas.create_text(75,30,text="Back",anchor='center',font='Times 14 bold')
   
def drawIntroScreen(app,canvas):
    canvas.create_rectangle(0,0,app.width,app.height,fill='#d2d5b8')
    canvas.create_rectangle(app.width/1.5, app.height/3.5, app.width/2.5, app.height/2.5, fill='#c9ba9b')
    canvas.create_text(app.width/1.87, app.height/2.9,
                       text='Sentiment Analysis', font='Times 18 bold',
                       fill='black', anchor='center')
    canvas.create_rectangle(app.width/1.5, app.height/3.5+170, app.width/2.5, app.height/2.5+170, fill='#c9ba9b')
    canvas.create_text(app.width/1.87, app.height/1.8,
                       text='Portfolio Analysis', font='Times 18 bold',
                       fill='black', anchor='center')
    canvas.create_rectangle(app.width/1.5, app.height/1.4, app.width/2.5, app.height/1.23, fill='#c9ba9b')
    canvas.create_text(app.width/1.87, app.height/1.3,
                       text='Stock Prediction', font='Times 18 bold',
                       fill='black', anchor='center')

def drawPerformSentiment(app,canvas):
    app.error=False
    try:
        if app.sentiment=='BUY':
            color='green'
        elif app.sentiment=='SELL':
            color='red'

        canvas.create_rectangle(0,0,app.width,app.height,fill='#c9ba9b')
        canvas.create_text(app.width/2, app.height/5.5,
                        text='Your Stock:'+app.inputStockSentiment, font='Times 20 bold',
                        fill=color)
        canvas.create_text(app.width/2, app.height/4,
                        text='Suggested:'+app.sentiment, font='Times 30 bold',
                        fill=color)
        canvas.create_text(app.width/2, app.height/1.5,text=app.headlines,font='Times 18 bold',
                        fill='black')
        canvas.create_rectangle(10,10,140,50,fill='pink')
        canvas.create_text(75,30,text="Back",anchor='center',font='Times 14 bold')
    except:
        app.mode='error'
        app.actionName='drawError'
        app.error=True
        app.actionList.append((app.actionName,app.mode))

def drawLinkBoxes(app,canvas):
    canvas.create_rectangle(3*app.width/4,app.height/2-5,3*app.width/4+70,app.height/2+15,fill='white')
    canvas.create_text(3*app.width/4+35,app.height/2+5,text="Link",anchor='center',font='Times 10 bold')
    canvas.create_rectangle(3*app.width/4,app.height/2+20,3*app.width/4+70,app.height/2+40,fill='white')
    canvas.create_text(3*app.width/4+35,app.height/2+30,text="Link",anchor='center',font='Times 10 bold')
    canvas.create_rectangle(3*app.width/4,app.height/2+45,3*app.width/4+70,app.height/2+65,fill='white')
    canvas.create_text(3*app.width/4+35,app.height/2+55,text="Link",anchor='center',font='Times 10 bold')
    canvas.create_rectangle(3*app.width/4,app.height/2+70,3*app.width/4+70,app.height/2+90,fill='white')
    canvas.create_text(3*app.width/4+35,app.height/2+80,text="Link",anchor='center',font='Times 10 bold')
    canvas.create_rectangle(3*app.width/4,app.height/2+95,3*app.width/4+70,app.height/2+115,fill='white')
    canvas.create_text(3*app.width/4+35,app.height/2+105,text="Link",anchor='center',font='Times 10 bold')
    canvas.create_rectangle(3*app.width/4,app.height/2+120,3*app.width/4+70,app.height/2+140,fill='white')
    canvas.create_text(3*app.width/4+35,app.height/2+130,text="Link",anchor='center',font='Times 10 bold')
    canvas.create_rectangle(3*app.width/4,app.height/2+145,3*app.width/4+70,app.height/2+165,fill='white')
    canvas.create_text(3*app.width/4+35,app.height/2+155,text="Link",anchor='center',font='Times 10 bold')
    canvas.create_rectangle(3*app.width/4,app.height/2+170,3*app.width/4+70,app.height/2+190,fill='white')
    canvas.create_text(3*app.width/4+35,app.height/2+180,text="Link",anchor='center',font='Times 10 bold')
    canvas.create_rectangle(3*app.width/4,app.height/2+195,3*app.width/4+70,app.height/2+215,fill='white')
    canvas.create_text(3*app.width/4+35,app.height/2+205,text="Link",anchor='center',font='Times 10 bold')
    canvas.create_rectangle(3*app.width/4,app.height/2+220,3*app.width/4+70,app.height/2+240,fill='white')
    canvas.create_text(3*app.width/4+35,app.height/2+230,text="Link",anchor='center',font='Times 10 bold')

def drawPerformPortfolioAnalysis(app,canvas):
    canvas.create_rectangle(0,0,app.width,app.height,fill='#e8e7d2')
    canvas.create_text(app.width/3.5, app.height/5.5,
                       text='Select a Portfolio Risk', font='Times 20 bold',
                       fill='black')
    canvas.create_text(app.width/3.5, app.height/3.4,
                       text='Conservative', font='Times 16 bold',
                       fill='black')
    canvas.create_rectangle(app.width/3.55, app.height/3.1, app.width/3.3, app.height/2.85, fill=app.boxColor1)  
    canvas.create_text(app.width/3.5, app.height/2.5,
                       text='Moderately Conservative', font='Times 16 bold',
                       fill='black')
    canvas.create_rectangle(app.width/3.55, app.height/2.35, app.width/3.3, app.height/2.2, fill=app.boxColor2)
    canvas.create_text(app.width/3.5, app.height/2,
                       text='Moderately Aggressive', font='Times 16 bold',
                       fill='black')
    canvas.create_rectangle(app.width/3.55, app.height/1.87, app.width/3.3, app.height/1.77, fill=app.boxColor3)
    canvas.create_text(app.width/3.5, app.height/1.65,
                       text='Aggressive', font='Times 16 bold',
                       fill='black')
    canvas.create_rectangle(app.width/3.55, app.height/1.57, app.width/3.3, app.height/1.5, fill=app.boxColor4)
    canvas.create_text(app.width/3.5, app.height/1.4,
                       text='Very Aggressive', font='Times 16 bold',
                       fill='black')
    canvas.create_rectangle(app.width/3.55, app.height/1.35, app.width/3.3, app.height/1.3, fill=app.boxColor5)  
    canvas.create_text(app.width/1.5+20, app.height/5.5,
                       text='Click in Boxes to input Ticker Symbols (10 max)', font='Times 20 bold',
                       fill='black')
    canvas.create_text(app.width/1.5+20, app.height/5.5+45,
                       text='Press Enter To Continue', font='Times 16 bold',
                       fill='black')
    canvas.create_rectangle(app.width/1.9, app.height/1.9-150, app.width/1.5, app.height/2.2-150,fill='white')
    canvas.create_rectangle(app.width/1.9, app.height/1.9-50, app.width/1.5, app.height/2.2-50,fill='white')
    canvas.create_rectangle(app.width/1.9, app.height/1.9+50, app.width/1.5, app.height/2.2+50,fill='white')
    canvas.create_rectangle(app.width/1.9, app.height/1.9+150, app.width/1.5, app.height/2.2+150,fill='white')
    canvas.create_rectangle(app.width/1.9, app.height/1.9+250, app.width/1.5, app.height/2.2+250,fill='white')
    canvas.create_rectangle(app.width/1.9+250, app.height/1.9-150, app.width/1.5+260, app.height/2.2-150,fill='white')
    canvas.create_rectangle(app.width/1.9+250, app.height/1.9-50, app.width/1.5+260, app.height/2.2-50,fill='white')
    canvas.create_rectangle(app.width/1.9+250, app.height/1.9+50, app.width/1.5+260, app.height/2.2+50,fill='white')
    canvas.create_rectangle(app.width/1.9+250, app.height/1.9+150, app.width/1.5+260, app.height/2.2+150,fill='white')
    canvas.create_rectangle(app.width/1.9+250, app.height/1.9+250, app.width/1.5+260, app.height/2.2+250,fill='white')
    canvas.create_text(app.width/1.7, app.height/2.05-150, text=app.inputStockPortfolio, font="Times 18 bold")
    canvas.create_text(app.width/1.7, app.height/2.05-50, text=app.inputStockPortfolio1, font="Times 18 bold")
    canvas.create_text(app.width/1.7, app.height/2.05+50, text=app.inputStockPortfolio2, font="Times 18 bold")
    canvas.create_text(app.width/1.7, app.height/2.05+150, text=app.inputStockPortfolio3, font="Times 18 bold")
    canvas.create_text(app.width/1.7, app.height/2.05+250, text=app.inputStockPortfolio4, font="Times 18 bold")
    canvas.create_text(app.width/1.7+255, app.height/2.05-150, text=app.inputStockPortfolio5, font="Times 18 bold")
    canvas.create_text(app.width/1.7+255, app.height/2.05-50, text=app.inputStockPortfolio6, font="Times 18 bold")
    canvas.create_text(app.width/1.7+255, app.height/2.05+50, text=app.inputStockPortfolio7, font="Times 18 bold")
    canvas.create_text(app.width/1.7+255, app.height/2.05+150, text=app.inputStockPortfolio8, font="Times 18 bold")
    canvas.create_text(app.width/1.7+255, app.height/2.05+250, text=app.inputStockPortfolio9, font="Times 18 bold")
    canvas.create_rectangle(10,10,140,50,fill='pink')
    canvas.create_text(75,30,text="Back",anchor='center',font='Times 14 bold')



def prop(perc):
 return 360 * perc #percent of stocks

def drawPieChart(app,canvas):
    canvas.create_rectangle(0,0,app.width,app.height,fill='beige')
    startValue=0
    count=0
    stocks=[]
    for stock in app.portfolios:
        if stock!='':
            stocks.append(stock)
    for asset,percentColor in app.percents.items():
        if asset=="Cash and Equivalents":
            asset="Cash"
        elif asset=="Fixed Income Securities":
            asset='T-Bills'
        color=percentColor[1]
        percent=percentColor[0]
        wholePercent=str(percent*100)
        wholePercent=wholePercent[0:4]
        canvas.create_arc(app.cx-300,app.cy-300, app.cx+300,app.cy+300, start=startValue,
                        extent=prop(percent), fill=color)
        canvas.create_text(app.width,app.height/(4)+count,text=str(asset)+':'+wholePercent+'%',fill=color,anchor='e',
                            font="Times 20 bold")
        startValue+=prop(percent)
        count+=50
    volatility=round(app.vol*app.weight*100,2)
    returns=round(app.ret*app.weight*100,2)
    canvas.create_text(app.width/2,50, text='Your Portfolio:', font='Times 20 bold', anchor='center')
    canvas.create_text(app.width,app.height/5, text='Legend:', font='Times 20 bold',anchor='e')
    canvas.create_text(0, app.height/5, text='Portfolio Risk:'+str(volatility)+'%', font='Times 20 bold',anchor='w')
    canvas.create_text(0, app.height/5+50, text='Portfolio Return:'+str(returns)+'%', font='Times 20 bold',anchor='w')
    canvas.create_rectangle(10,10,140,50,fill='pink')
    canvas.create_text(75,30,text="Back",anchor='center',font='Times 14 bold')
    canvas.create_rectangle(app.width-220,app.height-100,app.width-50,app.height-50,fill='pink')
    canvas.create_text(app.width-135,app.height-75,text="See Other Portfolios", font='Times 14 bold')


       


def drawStockPrediction(app,canvas):
    canvas.create_rectangle(0,0,app.width,app.height,fill='#c9ba98')
    canvas.create_text(app.width/2, app.height/3,text='Enter your stock (in ticker symbol!):',
                        font='Times 20 bold', fill='black')
    canvas.create_text(app.width/2, app.height/3+40,text='Press Enter To Continue',
                        font='Times 10 bold', fill='black')
    canvas.create_rectangle(app.width/3.5, app.height/3+60, app.width/1.5, app.height/3+110,fill='white')

    canvas.create_text(app.width/2, app.height/3+85, text=app.inputStockPrediction, font="Times 20 bold")
    canvas.create_rectangle(10,10,140,50,fill='pink')
    canvas.create_text(75,30,text="Back",anchor='center',font='Times 14 bold')
   
    canvas.create_rectangle(app.width/5,app.height/1.5,app.width/4.5+20,app.height/1.4,fill=app.boxColor6) #5 days
    canvas.create_text(app.width/5+22,app.height/1.4+20,text='Five Days',font='Times 12 bold')
    canvas.create_rectangle(200+app.width/5,app.height/1.5,200+app.width/4.5+20,app.height/1.4,fill=app.boxColor7) #10 days
    canvas.create_text(200+app.width/5+22,app.height/1.4+20,text='Ten Days',font='Times 12 bold')
    canvas.create_rectangle(400+app.width/5,app.height/1.5,400+app.width/4.5+20,app.height/1.4,fill=app.boxColor8) #15 days
    canvas.create_text(400+app.width/5+22,app.height/1.4+20,text='Fifteen Days',font='Times 12 bold')
    canvas.create_rectangle(600+app.width/5,app.height/1.5,600+app.width/4.5+20,app.height/1.4,fill=app.boxColor9) #30 days
    canvas.create_text(600+app.width/5+22,app.height/1.4+20,text='Thirty Days',font='Times 12 bold')


def drawPerformStockPrediction(app,canvas):
    app.error=False
    try:
        if app.days==30:
            scale=65
        elif app.days==5:
            scale=15
        elif app.days==10:
            scale=25
        elif app.days==15:
            scale=35
        canvas.create_rectangle(0,0,app.width,app.height,fill='#c9ba9b')
        canvas.create_text(app.width/2,50, text='Stock Prediction:'+app.inputStockPrediction, font='Times 20 bold', anchor='center')
        canvas.create_line(0,app.height/2,app.width,app.height/2,fill='black')
        diff=app.average[0]-app.lastPrice
        x0 = 25
        y0 = app.height/2
        x1=x0+2*app.width/scale
        y1= y0-(diff*(app.height/app.lastPrice)*5)
        if y1>y0:
            color='red'
        elif y1<y0:
            color='green'
        canvas.create_line(x0,y0,x1,y1,fill=color,width=5)
        canvas.create_text(25,app.height/2,text='$'+str(round(app.lastPrice,2)),fill='black')
        canvas.create_text(40,app.height/2-25,text="Today's Price:",fill='black')
        increment=2
        for i in range(len(app.average)):
            if i!=0:
                increment+=1
                diff=app.average[i]-app.average[i-1]
                x0 = x1
                y0 = y1
                x1=x0+2*app.width/scale
                y1= y0-(diff*(app.height/app.lastPrice)*5)
                if app.average[i]<app.average[i-1]:
                    color='red'
                elif app.average[i]>app.average[i-1]:
                    color='green'
                canvas.create_line(x0,y0,x1,y1,fill=color,width=3)
                if i%2==0:
                    canvas.create_text(x1,y1+15,text='$'+str(round(app.average[i],2)),fill='black')
                else:
                    canvas.create_text(x1,y1-15,text='$'+str(round(app.average[i],2)),fill='black')
        canvas.create_rectangle(10,10,140,50,fill='pink')
        canvas.create_text(75,30,text="Back",anchor='center',font='Times 14 bold')
    except:
        app.mode='error'
        app.actionName='drawError'
        app.error=True
        app.actionList.append((app.actionName,app.mode))


def drawSeeAllPortfolios(app,canvas):
    canvas.create_rectangle(0,0,app.width,app.height,fill='beige')
    canvas.create_line(0,app.height/2,app.width,app.height/2)
    canvas.create_line(app.width/2,0,app.width/2,app.height)
    startValue=0
    count=0
    counter=20
    weights={'Conservative':0.15,'Moderately Conservative':0.35,'Moderately Aggressive':0.55, 'Aggressive': 0.55, 'Very Aggressive':0.9}
    for k,v in app.portDict.items():
        if k!= app.selectedRisk:
            for kind, weight in weights.items():
                if kind==k:
                    stocks=[]
                    for stock in app.portfolios:
                        if stock!='':
                            stocks.append(stock)
                    counter=20
                    for asset,percentColor in v.items():
                        if asset=="Cash and Equivalents":
                            asset="Cash"
                        elif asset=="Fixed Income Securities":
                            asset='T-Bills'
                        color=percentColor[1]
                        percent=percentColor[0]
                        wholePercent=str(percent*100)
                        wholePercent=wholePercent[0:4]
                        if count==0:
                            canvas.create_arc(2.5*app.cx/5-150,2.5*app.cy/5-150, 2.5*app.cx/5+150,2.5*app.cy/5+150, start=startValue,
                                            extent=prop(percent), fill=color)
                            startValue+=prop(percent)
                            canvas.create_text(app.width/4,30,text=k,font='Times 18 bold')
                            volatility=round(app.vol*weight*100,2)
                            returns=round(app.ret*weight*100,2)
                            canvas.create_text(app.width/2,app.height/8, text='Legend:', font='Times 12 bold',anchor='e')
                            canvas.create_text(app.width/2,app.height/8+counter,text=str(asset)+':'+wholePercent+'%',fill=color,anchor='e',font="Times 12 bold")
                            canvas.create_text(0, app.height/8, text='Risk:'+str(volatility)+'%', font='Times 12 bold',anchor='w')
                            canvas.create_text(0, app.height/8+50, text='Return:'+str(returns)+'%', font='Times 12 bold',anchor='w')
                            counter+=20
                        elif count==1:
                            canvas.create_arc(7.5*app.cx/5-150,2.5*app.cy/5-150, 7.5*app.cx/5+150,2.5*app.cy/5+150, start=startValue,
                                            extent=prop(percent), fill=color)
                            startValue+=prop(percent)
                            canvas.create_text(3*app.width/4,30,text=k,font='Times 18 bold')
                            volatility=round(app.vol*weight*100,2)
                            returns=round(app.ret*weight*100,2)
                            canvas.create_text(app.width,app.height/8, text='Legend:', font='Times 12 bold',anchor='e')
                            canvas.create_text(app.width,app.height/8+counter,text=str(asset)+':'+wholePercent+'%',fill=color,anchor='e',font="Times 12 bold")
                            canvas.create_text(app.width/2+10, app.height/8, text='Risk:'+str(volatility)+'%', font='Times 12 bold',anchor='w')
                            canvas.create_text(app.width/2+10, app.height/8+50, text='Return:'+str(returns)+'%', font='Times 12 bold',anchor='w')
                            canvas.create_text(0, 5*app.height/8, text='Risk:'+str(volatility)+'%', font='Times 12 bold',anchor='w')
                            canvas.create_text(0, 5*app.height/8+50, text='Return:'+str(returns)+'%', font='Times 12 bold',anchor='w')
                            counter+=20
                        elif count==2:
                            canvas.create_arc(2.5*app.cx/5-150,7.5*app.cy/5-150, 2.5*app.cx/5+150,7.5*app.cy/5+150, start=startValue,
                                            extent=prop(percent), fill=color)
                            startValue+=prop(percent)
                            canvas.create_text(app.width/4,410,text=k,font='Times 18 bold')
                            volatility=round(app.vol*weight*100,2)
                            returns=round(app.ret*weight*100,2)
                            canvas.create_text(app.width/2,5*app.height/8, text='Legend:', font='Times 12 bold',anchor='e')
                            canvas.create_text(0, 5*app.height/8, text='Risk:'+str(volatility)+'%', font='Times 12 bold',anchor='w')
                            canvas.create_text(0, 5*app.height/8+50, text='Return:'+str(returns)+'%', font='Times 12 bold',anchor='w')
                            canvas.create_text(app.width/2,5*app.height/8+counter,text=str(asset)+':'+wholePercent+'%',fill=color,anchor='e',font="Times 12 bold")
                            counter+=20
                        elif count==3:
                            canvas.create_arc(7.5*app.cx/5-150,7.5*app.cy/5-150, 7.5*app.cx/5+150,7.5*app.cy/5+150, start=startValue,
                                            extent=prop(percent), fill=color)
                            startValue+=prop(percent)
                            canvas.create_text(3*app.width/4,410,text=k,font='Times 18 bold')
                            volatility=round(app.vol*weight*100,2)
                            returns=round(app.ret*weight*100,2)
                            canvas.create_text(app.width,5*app.height/8, text='Legend:', font='Times 12 bold',anchor='e')
                            canvas.create_text(app.width/2+10, 5*app.height/8, text='Risk:'+str(volatility)+'%', font='Times 12 bold',anchor='w')
                            canvas.create_text(app.width/2+10, 5*app.height/8+50, text='Return:'+str(returns)+'%', font='Times 12 bold',anchor='w')
                            canvas.create_text(app.width,5*app.height/8+counter,text=str(asset)+':'+wholePercent+'%',fill=color,anchor='e',font="Times 12 bold")
                            counter+=20
                    count+=1
    canvas.create_rectangle(10,10,140,50,fill='pink')
    canvas.create_text(75,30,text="Back",anchor='center',font='Times 14 bold')

def drawErrorScreen(app,canvas):
    canvas.create_rectangle(0,0,app.width,app.height,fill='#c9ba9b')
    canvas.create_text(app.width/2,app.height/2, text="ERROR! PLEASE TRY AGAIN",font="Times 30 bold",fill='red')              
    canvas.create_rectangle(10,10,140,50,fill='pink')
    canvas.create_text(75,30,text="Back",anchor='center',font='Times 14 bold')

def splashScreen(app,canvas):
    canvas.create_rectangle(0,0,app.width,app.height,fill='#bdc2bb')
    canvas.create_text(app.width/2, app.height/2-100,
                       text='Welcome to Financial Analysis!', font='Times 30 bold',
                       fill='black') #Screen A
    canvas.create_text(app.width/2, app.height/1.5-150,
                       text='Enter a username and a password', font='Times 20 bold',
                       fill='black',anchor='center')
    canvas.create_text(app.width/2,app.height/1.5-100,text='Press Space to Begin', font="Times 18 bold", fill='black')
    canvas.create_rectangle(app.width/2,app.height-300,app.width/2+200,app.height-250, fill='white')
    canvas.create_text(app.width/2+100,app.height-275, text=app.inputUser, font="Times 16 bold", fill='black')
    canvas.create_rectangle(app.width/2,app.height-200,app.width/2+200,app.height-150,fill='white')
    canvas.create_text(app.width/2+100,app.height-175, text=app.inputPass, font="Times 16 bold", fill='black')
    canvas.create_text(app.width/2-100,app.height-275,text='Username:', font="Times 18 bold", fill='black')
    canvas.create_text(app.width/2-100,app.height-175,text='Password:', font="Times 18 bold", fill='black')
def redrawAll(app, canvas):
    if app.actionName=='splash' and (app.mode=='start' or app.mode=='user' or app.mode=='pass'):
        splashScreen(app,canvas)
    if app.actionName=='introScreen' and app.mode=='userPicks': #Screen B
           drawIntroScreen(app,canvas)
    if  app.mode=='sentStock' and app.actionName=='sentimentAnalysis':
        drawSentimentAnalysis(app,canvas)
    if app.startTyping==True:
        canvas.create_text(app.width/2, app.height/1.65, text=app.inputStockSentiment, font='Times 20 bold')
    if app.mode=='sentimentAnalysis':
        drawPerformSentiment(app,canvas)
        drawLinkBoxes(app,canvas)
    if app.actionName=='portfolioAnalysis':
        drawPerformPortfolioAnalysis(app,canvas)
    if app.mode=='portfolioAnalysis' and app.actionName=='drawPortfolio':
        drawPieChart(app,canvas)
    if app.actionName=='stockPrediction' and app.mode=='stockPred': #Screen C
        drawStockPrediction(app,canvas)
    if app.actionName=='predictStock' and app.mode=='performPred': #Screen D
        drawPerformStockPrediction(app,canvas)
    if app.mode=='seeAll' and app.actionName=='allPortfolios':
        drawSeeAllPortfolios(app,canvas)
    if app.error==True and app.mode=='error' and app.actionName=='drawError':
        drawErrorScreen(app,canvas)
    if app.wrongPassword==True and app.mode=='error' and app.actionName=='drawError':
        drawErrorScreen(app,canvas)


runApp(width=1200, height=800)